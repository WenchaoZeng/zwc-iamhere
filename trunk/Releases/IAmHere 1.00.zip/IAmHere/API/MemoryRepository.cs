﻿using System;
using System.Collections.Generic;
using System.Web;

namespace IAmHere.API
{
    public class MemoryRepository : IRepository
    {
        static Dictionary<string, List<Person>> rooms = new Dictionary<string, List<Person>>();

        public void Update(string room, Person person)
        {
            if (string.IsNullOrEmpty(room) || string.IsNullOrEmpty(person.Name))
            {
                return;
            }
            person.LastRefresh = DateTime.Now;

            if (!rooms.ContainsKey(room))
            {
                rooms.Add(room, new List<Person>());
            }

            // Try to update the old one. 
            for (int i = 0; i < rooms[room].Count; i++)
            {
                if (rooms[room][i].Name == person.Name)
                {
                    rooms[room][i].X = person.X;
                    rooms[room][i].Y = person.Y;
                    rooms[room][i].LastRefresh = person.LastRefresh;
                    return;
                }
            }

            rooms[room].Add(person);
        }
        public List<Person> AllPersons(string room)
        {
            if (!string.IsNullOrEmpty(room) && rooms.ContainsKey(room))
            {
                List<Person> result = new List<Person>();

                // Only return the latest  users.
                foreach (Person person in rooms[room])
                {
                    if ((DateTime.Now - person.LastRefresh) < TimeSpan.FromHours(1))
                    {
                        result.Add(person);
                    }
                }

                return result;
            }
            return new List<Person>();
        }

        public void Dispose() { }
    }
}