﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Data.OleDb;

namespace IAmHere.API
{
    public class MSAccessRepository : IRepository
    {
        public void Update(string room, Person person)
        {
            if (string.IsNullOrEmpty(room) || string.IsNullOrEmpty(person.Name))
            {
                return;
            }

            if (dbExist(room, person.Name))
            {
                dbUpdate(room, person);
            }
            else
            {
                dbInsert(room, person);
            }
        }

        public List<Person> AllPersons(string room)
        {
            return dbSelect(room);
        }

        public void Dispose() { }

#region Database helpers

        bool dbExist(string room, string personName)
        {
            OleDbDataReader reader = dbExecute("select ID from Persons where Room = ? and Name = ?", room, personName);
            return reader.HasRows;
        }
        void dbUpdate(string room, Person person)
        {
            dbExecute("update Persons set X = ?, Y = ? where Room = ? and Name = ?"
                , person.X, person.Y, room, person.Name);
        }
        void dbInsert(string room, Person person)
        {
            dbExecute("insert into Persons(Room, Name, X, Y) values(?, ?, ?, ?)"
                , room, person.Name, person.X, person.Y);
        }

        List<Person> dbSelect(string room)
        {
            List<Person> personList = new List<Person>();
            OleDbDataReader reader = dbExecute("select Name, X, Y from Persons where Room = ?", room);
            if (reader.HasRows)
            {
                while (reader.Read())
                {
                    personList.Add(new Person()
                    {
                        Name = (string)reader["Name"],
                        X = (reader["X"].GetType() == typeof (DBNull) ? 0.0 : (double)reader["X"]),
                        Y = (reader["Y"].GetType() == typeof (DBNull) ? 0.0 : (double)reader["Y"])
                    });
                }
            }
            return personList;
        }
        OleDbDataReader dbExecute(string sqlCommand, params object[] parameters)
        {
            lock (synFlag)
            {
                if (_connection == null)
                {
                    _connection = newConnection();
                }
                OleDbCommand command = new OleDbCommand(sqlCommand, _connection);
                foreach (object value in parameters)
                {
                    command.Parameters.AddWithValue("?", value);
                }
                if (sqlCommand[0] == 's') // select command
                {
                    return command.ExecuteReader();
                }
                else // update, delete, insert commands
                {
                    command.ExecuteNonQuery();
                    return null;
                }
            }
        }
        static OleDbConnection _connection = null;
        static object synFlag = new object();
        OleDbConnection newConnection()
        {
            string connectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + HttpContext.Current.Server.MapPath("/App_Data/IAmHere.mdb");
            OleDbConnection connection = new OleDbConnection(connectionString);
            connection.Open();
            return connection;
        }
#endregion
    }
}